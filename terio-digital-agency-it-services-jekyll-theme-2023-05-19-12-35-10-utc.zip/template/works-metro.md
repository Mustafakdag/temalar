---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

title: Portfolio (Metro)
layout: builder

# Intro Begin
intro: true
intro_title: "We Love to Build Something Amazing"
intro_subtitle: "Portfolio"
# Intro End

sections: portfolio-metro
---