---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

title: Blog (Carousel)
headerStyle: "three"
layout: builder
sections: blog-carousel-three,blog-grid
---